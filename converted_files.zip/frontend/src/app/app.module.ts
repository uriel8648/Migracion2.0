import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Components
import { AppComponent } from './app.component';
import { TodoListComponent } from './components/todo-list/todo-list.component';
import { TodoFormComponent } from './components/todo-form/todo-form.component';
import { TodoDetailComponent } from './components/todo-detail/todo-detail.component';

// Services
import { TodoService } from './services/todo.service';

// Routing
import { AppRoutingModule } from './app-routing.module';

/**
 * Main application module that serves as the entry point for the Angular application.
 * 
 * This module:
 * - Imports core Angular modules (BrowserModule, HttpClientModule, FormsModule)
 * - Declares all application components
 * - Provides application-wide services
 * - Bootstraps the root AppComponent
 * 
 * The application follows a feature-based organization where:
 * - Components are organized by feature (todo management)
 * - Services handle data access and business logic
 * - Routing is configured in a separate AppRoutingModule
 */
@NgModule({
  declarations: [
    // Root component that hosts the application
    AppComponent,
    
    // Todo feature components
    TodoListComponent,
    TodoFormComponent,
    TodoDetailComponent
  ],
  imports: [
    // Angular core modules
    BrowserModule,
    BrowserAnimationsModule,
    
    // HTTP client for API communication (replaces $http)
    HttpClientModule,
    
    // Form handling modules
    FormsModule,
    ReactiveFormsModule,
    
    // Application routing configuration
    AppRoutingModule
  ],
  providers: [
    // Application-wide services
    TodoService
  ],
  bootstrap: [
    // Root component that gets bootstrapped
    AppComponent
  ]
})
export class AppModule { }